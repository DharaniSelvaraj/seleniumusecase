package cs_18_selectbox;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectBoxampleox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 18:
			1. The user should go to "http://newtours.demoaut.com/"
			2. The user should enter the Login Credential of username and password as "mercury"
				1. Identify the username text box		name="userName"
				2. Type the input as "mercury"
				3. Identify the password text box		name="password"
				4. Type the input as "mercury"
			3. The user should click on Signin Button
				1. Identify the Signin Button		name="login"
				2. Click the Signin Button
			4. The user should check if  'India' is present or not in the Departing from list box.
				1. Identify the Departing from select box	 name="fromPort"
				2. Check if  'India' is present or not in the Departing from list box.
*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://newtours.demoaut.com");
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		Select departure=new Select(driver.findElement(By.name("fromPort")));
		List<WebElement> departure_list=departure.getOptions();
		for(WebElement e:departure_list)
		{
			if(e.getText().equalsIgnoreCase("India"))
			{
				System.out.println("India is present in select list box");
				return;
			}
		}
		System.out.println("India is not present in select list box");
		driver.close();
	}

}
