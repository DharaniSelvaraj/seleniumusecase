package cs_8_default_values_selected;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DefaultValuesInSelect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 8://verify the default values selected in the Departing from is not same as Arriving In select box
			1. The user should go to "http://newtours.demoaut.com/"
			2. The user should enter the Login Credential of username and password as "mercury"
				1. Identify the username text box		name="userName"
				2. Type the input as "mercury"
				3. Identify the password text box		name="password"
				4. Type the input as "mercury"
				5. Identify the Signin Button		name="login"
				6. Click the Signin Button
			3. The user should verify the default values selected in the Departing from is not same as Arriving In select box*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://newtours.demoaut.com");
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		Select departureSelect=new Select(driver.findElement(By.name("fromPort")));
		String departure=departureSelect.getFirstSelectedOption().getText();
		
		Select arrivalSelect=new Select(driver.findElement(By.name("toPort")));
		String arrival=arrivalSelect.getFirstSelectedOption().getText();
		
		if(!departure.equals(arrival))
		{
			System.out.println("Departure and arrival location are different");
		}
		else
		{
			System.out.println("Departure and arrival location are same");
		}


	}

}
