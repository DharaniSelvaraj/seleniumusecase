package cs_1_1_example_for_GetText_Compare_the_field_data;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GetTextExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case study 1.1: //Example for getText() and compare fields
		1. The user should go to "https://www.amazon.in"
		2. The user should click Start here. link.
			1. Identify the Start here. link 	
			2. Click the Start here. link
		3. The user should fill required details
			1. Identify the your name text box	id="ap_customer_name"
		<input type="text" maxlength="50" id="ap_customer_name" autocomplete="off" name="customerName" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field" xpath="1">
			2. Type the input as "Aaaaa"
			3. Identify the Mobile number text box		id="ap_phone_number"
		<input type="tel" maxlength="50" id="ap_phone_number" placeholder="Mobile number" name="email" tabindex="3" class="a-input-text a-span12 a-spacing-micro auth-required-field auth-require-phone-validation" data-validation-id="phoneNumber" xpath="1">
			4. Type the input as "1234567898"
			5. Identify the Email text box 		id="ap_email"
		<input type="email" maxlength="64" id="ap_email" name="secondaryLoginClaim" tabindex="4" class="a-input-text a-span12 auth-require-email-validaton" data-validation-id="email" style="" xpath="1">
			6. Type the input as "aaa@gmail.com"
			7. Identify the password text box	id="ap_password"
		<input type="password" maxlength="1024" id="ap_password" autocomplete="off" placeholder="At least 6 characters" name="password" tabindex="5" class="a-input-text a-span12 auth-required-field auth-require-fields-match auth-require-password-validation" xpath="1">
			8. Type the input as "Aaa@01"
		4. Compare fields
		 	1. Check your name entered is equal to Aaaaa using getText()
		 	2. Check Email entered is equal to aaa@gmail.com*/
	System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	//1. The user should go to "https://www.amazon.in"
	driver.get("https://www.amazon.in");
	//2. The user should click Start here. link.
	driver.findElement(By.linkText("Start here.")).click();
	//3. The user should fill required details
	driver.findElement(By.id("ap_customer_name")).sendKeys("Aaaaa");
	driver.findElement(By.id("ap_phone_number")).sendKeys("1234567898");
	driver.findElement(By.id("ap_email")).sendKeys("aaa@gmail.com");
	driver.findElement(By.id("ap_password")).sendKeys("Aaa@01");
	//4. Compare fields
	WebDriverWait wait = new WebDriverWait(driver, 15);
	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ap_customer_name")));
	WebElement customer_name_ele=driver.findElement(By.id("ap_customer_name"));
	String name=customer_name_ele.getText();
	System.out.println("Customer name using getText():"+name);
	WebElement email_ele=driver.findElement(By.id("ap_email"));
	String email=email_ele.getText();
	System.out.println("Customer email using getText():"+email);
	//driver.close();
		if(name.equals("Aaaaa")&& email.equals("aaa@gmail.com"))
		{
			System.out.println("The fields are same");
		}
	}

}
