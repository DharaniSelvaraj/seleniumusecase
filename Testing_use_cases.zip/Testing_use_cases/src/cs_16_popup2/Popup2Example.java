package cs_16_popup2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Popup2Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 16:

			1. The user should go to "file:///C:/Dharani/Testing/HTML%20Pages/HTML%20Pages/Popup2.html"
			2. The user should click on �Click on me� Button	//tagname=button
			3. The user should get & print the text on the pop up window 	
			4. The user can accept/dismiss the pop up window	
			5. The user should get the confirmation message based on accept / dismiss 
			6. The user should verify whether it is an accept / dismiss alert, based on the confirmation message & print in console. 
*/
			System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("file:///C:/Dharani/Testing/HTML%20Pages/HTML%20Pages/Popup2.html");
			driver.findElement(By.tagName("button")).click();
			System.out.println("Alert message :");
			System.out.println(driver.switchTo().alert().getText());	
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.switchTo().alert().dismiss();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String confirmation=driver.findElement(By.id("confirmdemo")).getText();
			System.out.println("Confirmation message :"+confirmation);
			if(confirmation.contains("OK"))
			{
				System.out.println("Alert is accepted");
			}
			else
			{
				System.out.println("Alert is dismissed");
			}
			driver.close();
	}

}
