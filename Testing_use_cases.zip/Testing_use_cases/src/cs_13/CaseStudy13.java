package cs_13;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CaseStudy13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study : 13
1. The user should go to "http://www.fedex.com/sg/"
2. The user should verify whther the User ID & Password text box is available or not?
	1. Identify the Sign Up/Log In link
	2. Click the Sign Up/Log In link
<a href="#" class="fxg-link fxg-dropdown-js fxg-keyboard" data-default-signintext="Sign Up/Log In"><span aria-hidden="true" class="fxg-user-options__sign-in-text" tabindex="-1">Sign Up/Log In </span><img class="fxg-user-options__icon" alt="Sign in to Fedex.com" src="https://www.fedex.com/content/dam/fedex-com/common/sprite-placeholder.png"></a>
	3. Identify the UserId text box		id="NavLoginUserId"
<input id="NavLoginUserId" tabindex="0" focusable="true" type="text" class="fxg-field__input-text fxg-field__input--required" name="user" required="" title="User ID" aria-required="true" data-errmsg="Sorry, this is a required field." xpath="1">
	4. Identify the Password text box	 id="NavLoginPassword" 
<input id="NavLoginPassword" autocomplete="off" tabindex="0" focusable="true" type="password" class="fxg-field__input-text fxg-field__input--required" name="pwd" required="" title="Password" aria-required="true" data-errmsg="Sorry, this is a required field." xpath="1">
3. The user should get & print the already available default text avaialable User ID & Password Text box & Set new value.
	1. Identify the UserId text box		id="NavLoginUserId"
	2. Get the default value of User ID text box
	3. Type the input as "Aaaaa"
	4. Identify the Password text box	 id="NavLoginPassword" 
	5. Get the default value of Password text box
	6. Type the input as "Aaaaa"
4. The user should verify the Remember me check box, should be selected by default
	1. Identify the Remember me check box		id="NavLoginRememberMe"
<input type="checkbox" aria-label="remember me checkbox" role="checkbox" aria-checked="false" name="rememberme" id="NavLoginRememberMe" class="fxg-field__input-checkbox" value="rememberme">
	2. Verify whether the Remember me check box is enabled 
		If it is checked then move to next step else if it is not checked then check the remember me check box should be checked
5. The user should click on the LOG IN button
	1. Identify the LOG IN button		//button[@class='fxg-button fxg-button--orange fdx-login_error-label-change']
<button type="submit" class="fxg-button fxg-button--orange fdx-login_error-label-change" xpath="1">Log In</button>
	2. Click the LOG IN button */
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.fedex.com/sg/");
		WebElement signEle=driver.findElement(By.linkText("Sign Up/Log In"));
		signEle.click();
		WebElement userIdELe=driver.findElement(By.id("NavLoginUserId"));
		String defaultUserIDValue=userIdELe.getAttribute("title");
		System.out.println("The default value of UserID:"+defaultUserIDValue);
		WebElement passwordEle=driver.findElement(By.id("NavLoginPassword"));
		String defaultPasswordValue=passwordEle.getAttribute("title");
		System.out.println("The default value of password:"+defaultPasswordValue);
		userIdELe.sendKeys("Aaaaa");
		passwordEle.sendKeys("Aaaaa");
		WebElement rememberEle=driver.findElement(By.xpath("//label[contains(text(),'Remember Me')]"));
		rememberEle.click();
		WebElement loginEle=driver.findElement(By.xpath("//button[@class='fxg-button fxg-button--orange fdx-login_error-label-change']"));
		loginEle.click();
	}
	

}
