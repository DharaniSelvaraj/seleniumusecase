package cs_7_working_with_select;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 7: // Working with Select /List object
			1. The user should go to "http://newtours.demoaut.com/"
			2. The user should enter the Login Credential of username and password as "mercury"
				1. Identify the username text box	name="userName"
				2. Type the input as "mercury"
				3. Identify the password text box 	name="password"
				4. Type the input as "mercury"
			3. The user should click on Signin Button
				1. Identify the Signin Button		name="login"
				2. Click the Signin Button
			4. The user should select the passengers count as "4" using select object by index
				1. Identify the passengers select box		name="passCount"
				2. Select the passengers count as "4" using select object by index	index=3
			5. The user should select Departure location, Month & Date using select by Value
				1. Identify the Departing from select box	 name="fromPort"
				2. Select the Departing from as "London" using select by value 		value="London"
				3. Identify the On select box to choose month and date
					1. Identify the month select box	name="fromMonth"
					2. Select the month as "May" using select by value	value="5"
					3. Identify the date select box		name="fromDay"
					4. Select the date as "10" using select by value	value="10"
			6. The user should select Arrival location, Month,& Date  using select by Visible Text
				1. Identify the Arrival In select box		name="toPort"
				2. Select the Arrival In as "Paris" using select by Visible Text	text="Paris"
				3. Identify the Returning select box to choose month and date
					1. Identify the month select box	name="toMonth"
					2. Select the month as "May" using select by Visible Text	text="May"
					3. Identify the date select box		name="toDay"
					4. Select the date as "14" using select by Visible Text		text="14"
			7. The user should click on Continue booking the flight ticket
				1. Identify the CONTINUE button		name="findFlights"
				2. Click on the CONTINUE button*/
		
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://newtours.demoaut.com");
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		Select pass_count=new Select(driver.findElement(By.name("passCount")));
		pass_count.selectByIndex(3);
		Select departure=new Select(driver.findElement(By.name("fromPort")));
		departure.selectByValue("London");
		Select fromMonth=new Select(driver.findElement(By.name("fromMonth")));
		fromMonth.selectByValue("5");
		Select fromDay=new Select(driver.findElement(By.name("fromDay")));
		fromDay.selectByValue("10");
		Select arrival=new Select(driver.findElement(By.name("toPort")));
		arrival.selectByVisibleText("Paris");
		Select toMonth=new Select(driver.findElement(By.name("toMonth")));
		toMonth.selectByVisibleText("May");
		Select toDay=new Select(driver.findElement(By.name("toDay")));
		toDay.selectByVisibleText("14");
		driver.findElement(By.name("findFlights")).click();
	}

}
