package cs_10_listing_autosuggest_data;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ListingAutoSuggestDataExample {
	public static void main(String args[]) {
	/*case study 10:
		Goto Google search engine
		Search for any term/word
		Capture the data in autosuggest window and print it.
		1. The user should go to "https://www.google.com"
		2. The user should search for any word (Automation Testing)
			1. Identify the search text box  	//input[@name='q']
		<input class="gLFyf gsfi" maxlength="2048" name="q" type="text" jsaction="paste:puy29d" aria-autocomplete="both" aria-haspopup="false" autocapitalize="off" autocomplete="off" autocorrect="off" role="combobox" spellcheck="false" title="Search" value="" aria-label="Search" data-ved="0ahUKEwjOreON___kAhUT4o8KHVYxAeYQ39UDCAQ" xpath="1">
			2. Type the input as "Automation Testing"
		3. The user should capture the data in autosuggest window and print it.
			1. Identify the property for autosuggest window   	xpath="//ul[@class='erkvQe']//li"	
			2. Store the elements in list and print the list*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String searchString="Automation Testing";
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys(searchString);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@class='erkvQe']//li")));
		List<WebElement> element_list = driver.findElements(By.xpath("//ul[@class='erkvQe']//li"));
			for(WebElement e:element_list)
			{
				System.out.println(e.getText());
			}
	}
	
}
