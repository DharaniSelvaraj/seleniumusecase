package cs_6_examples_to_findElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FindElementsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in");
		WebElement ele = driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
		Select itemsCategory=new Select(ele);
		itemsCategory.selectByIndex(11);
		String search_term = "Da Vinci Code";
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(search_term);
        driver.findElement(By.xpath("//input[@tabindex = '10']")).click();
        WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[@class = 'a-size-medium a-color-base a-text-normal']")));
		List<WebElement> Titles = driver.findElements(By.xpath("//span[@class = 'a-size-medium a-color-base a-text-normal']"));
		List<WebElement> prices = driver.findElements(By.className("a-price-whole"));
        for(int i=0;i<Titles.size();i++) {
            System.out.println(Titles.get(i).getText()+"     "+prices.get(i).getText());
        }
        
        //driver.close();

	}

}
