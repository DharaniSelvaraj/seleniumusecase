package cs_12_explicit_wait;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWaitExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 12:Explicit wait
		1. titleContains
		2. titleIs
		3. ExpectedConditions.presenceOfElementLocated(locator)
*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String searchString="Automation Testing";	
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys(searchString);
		driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK']")).click();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		//1. titleContains
		wait.until(ExpectedConditions.titleContains("Automation Testing"));
		System.out.println(driver.getTitle());
		//2. titleIs
		driver.get("https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp");
		wait.until(ExpectedConditions.titleIs("Create your Google Account"));
		//3. ExpectedConditions.presenceOfElementLocated(locator)
		wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("ul")));
		driver.close();
		
	}

	

}
