package cs_14;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CaseStudy14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study : 14

		1. The user should go to "http://destinationqa.com/contact-us/"
		2. The user should get total no. of Text boxes avaialable.		xpath="//input[@type='text']"
		3. The user should get & print	the default text on the address text box. 
					//h5[contains(text(),'A303 Samrajya, Paud Rd, Kothrud, Pune 411038')]
*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://destinationqa.com/contact-us/");
		List<WebElement> textbox_list=driver.findElements(By.xpath("//input[@type='text']"));
		System.out.println("Total number of text boxes available:"+textbox_list.size());
		WebElement addEle=driver.findElement(By.xpath("//h5[contains(text(),'A303 Samrajya, Paud Rd, Kothrud, Pune 411038')]"));
		System.out.println(addEle.getText());
		driver.close();
	}

}
