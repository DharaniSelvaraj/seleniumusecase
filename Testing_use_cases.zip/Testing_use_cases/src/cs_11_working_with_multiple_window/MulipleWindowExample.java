package cs_11_working_with_multiple_window;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MulipleWindowExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 11:Working With Multiple Window of a Browser
		1. Goto Gmail Create account URL
		2.  Click on Term of Service
		3.  Click on Privacy Policy
		4. After all the windows are opened fetch the title & all the links avialable in each of the window
		1. The user should go to create account url "https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp"
		2. The user should click on Term of Service
			1. Identify the Term of Service 
		<a href="https://accounts.google.com/TOS?loc=IN&amp;hl=en" target="_blank">Terms</a>
			2. Click on the Term of Service
		3. The user should click on Privacy Policy
			1. Identify the Privacy Policy
		<a href="https://accounts.google.com/TOS?loc=IN&amp;hl=en&amp;privacy=true" target="_blank">Privacy</a>
			2. Click on the Privacy Policy
		4. After all the windows are opened user should fetch the title and all the links available in each of the window
*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp");
		driver.findElement(By.linkText("Terms")).click();
		driver.findElement(By.linkText("Privacy")).click();
		Set<String> winHandles = driver.getWindowHandles();
		for(String win:winHandles)
		{
			driver.switchTo().window(win);
			System.out.println("Title of the window:"+driver.getTitle());
			System.out.println("The link of the window:"+driver.getCurrentUrl());
			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("a")));
			List<WebElement> links=driver.findElements(By.tagName("a"));
			for(WebElement e:links)
			{
				System.out.println(e.getText()+"  -  "+e.getAttribute("href"));
			}
			System.out.println("\n\n\n");
		}
	}

}
