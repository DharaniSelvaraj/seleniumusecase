package cs_5_gettitles_explicitwait;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GetTitles_ExplicitWaitExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*case study: 5	// getTitle() and Explicit wait based on the Title

	1. The user should go to "https://www.google.com"
	2. The user should search for Automation Testing
		1. Identify the search text box  	//input[@name='q']
	<input class="gLFyf gsfi" maxlength="2048" name="q" type="text" jsaction="paste:puy29d" aria-autocomplete="both" aria-haspopup="false" autocapitalize="off" autocomplete="off" autocorrect="off" role="combobox" spellcheck="false" title="Search" value="" aria-label="Search" data-ved="0ahUKEwjOreON___kAhUT4o8KHVYxAeYQ39UDCAQ" xpath="1">
		2. Type the input as "Automation Testing" 
	3. The user should click on Google Search button	
		1. Identify the Google Search button		//div[@class='VlcLAe']//input[@name='btnK']
	<input class="gNO89b" value="Google Search" aria-label="Google Search" name="btnK" type="submit" data-ved="0ahUKEwjOreON___kAhUT4o8KHVYxAeYQ4dUDCAY" xpath="1" style="">
		2. Click the Google Search button
	4. Explicitwait based on titlecontains
	5. Get the title should be same as search term*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String searchString="Automation Testing";
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys(searchString);
		driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK']")).click();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		  wait.until(ExpectedConditions.titleContains("Automation Testing"));

		  //Get and store page title in to variable
		  String title = driver.getTitle();
		  if(title.contains(searchString))
		  {
			  System.out.println("Search term matched");
		  }
	}

}
