package cs_15_popup_window;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Sleeper;

public class PopupWindowExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 15
		1. The user should go to "file:///C:/Users/iBall/Downloads/HTML%20Pages/HTML%20Pages/popup.html"
		2. The user should click on Tryit Button	//tagname=button
		3. The user should get & print the text on the pop up window 
		4. The user should accept the pop up window
		5. The user should click again on the tryit button	//tagname=button
		6. The user should dismiss the pop up window.*/
		//System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\iBall\\workspace\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/iBall/Downloads/HTML%20Pages/HTML%20Pages/popup.html");
		driver.findElement(By.tagName("button")).click();
		System.out.println(driver.switchTo().alert().getText());	
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.switchTo().alert().accept();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.tagName("button")).click();
		driver.switchTo().alert().dismiss();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.close();
	}

}
