package cs_9_verify_the_height_width;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyHeightWidth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case Study 9:Verify the Height & Width
		Goto New tours application
		Verify the Height & Width of Username & Password text box is same.
		1. The user should go to "http://newtours.demoaut.com/"
		2. The user should Verify the Height & Width of Username & Password text box is same.
			1. Identify the username text box		name="userName"
			2. Identify the password text box		name="password"
			3. Get height and width of username and password text box and verify*/
		System.setProperty("webdriver.chrome.driver", "C:\\Dharani\\Testing Jars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://newtours.demoaut.com");
		WebElement userNameEle=driver.findElement(By.name("userName"));
		WebElement passwordEle=driver.findElement(By.name("password"));
		int height_UserName=userNameEle.getSize().getHeight();
		int width_UserName=userNameEle.getSize().getWidth();
		int height_Password=passwordEle.getSize().getHeight();
		int width_Password=passwordEle.getSize().getWidth();
		if(height_Password==height_UserName)
		{
			System.out.println("Height of username and password text box are same");
		}
		else
		{
			System.out.println("Height of username and password text box are different");
		}
		if(width_Password==width_UserName)
		{
			System.out.println("Width of username and password text box are same");
		}
		else
		{
			System.out.println("Width of username and password text box are different");
		}
		driver.close();
	}

}
