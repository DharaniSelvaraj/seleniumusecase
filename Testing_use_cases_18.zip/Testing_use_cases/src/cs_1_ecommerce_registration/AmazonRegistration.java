package cs_1_ecommerce_registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonRegistration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Case study 1: //Registration
			1. The user should go to "https://www.amazon.in"
			2. The user should click Start here. link.
				1. Identify the Start here. link 	
				2. Click the Start here. link
			3. The user should fill required details
				1. Identify the your name text box	id="ap_customer_name"
			<input type="text" maxlength="50" id="ap_customer_name" autocomplete="off" name="customerName" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field" xpath="1">
				2. Type the input as "Aaaaa"
				3. Identify the Mobile number text box		id="ap_phone_number"
			<input type="tel" maxlength="50" id="ap_phone_number" placeholder="Mobile number" name="email" tabindex="3" class="a-input-text a-span12 a-spacing-micro auth-required-field auth-require-phone-validation" data-validation-id="phoneNumber" xpath="1">
				4. Type the input as "1234567898"
				5. Identify the Email text box 		id="ap_email"
			<input type="email" maxlength="64" id="ap_email" name="secondaryLoginClaim" tabindex="4" class="a-input-text a-span12 auth-require-email-validaton" data-validation-id="email" style="" xpath="1">
				6. Type the input as "aaa@gmail.com"
				7. Identify the password text box	id="ap_password"
			<input type="password" maxlength="1024" id="ap_password" autocomplete="off" placeholder="At least 6 characters" name="password" tabindex="5" class="a-input-text a-span12 auth-required-field auth-require-fields-match auth-require-password-validation" xpath="1">
				8. Type the input as "Aaa@01"
			4. The user should click the continue button
				1. Identify the continue button   id="continue"
			<input id="continue" tabindex="8" class="a-button-input" type="submit" aria-labelledby="auth-continue-announce" style="" xpath="1">
				2. Click the continue button*/
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\iBall\\workspace\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//1. The user should go to "https://www.amazon.in"
		driver.get("https://www.amazon.in");
		//2. The user should click Start here. link.
		driver.findElement(By.linkText("Start here.")).click();
		//3. The user should fill required details
		driver.findElement(By.id("ap_customer_name")).sendKeys("Aaaaa");
		driver.findElement(By.id("ap_phone_number")).sendKeys("1234567898");
		driver.findElement(By.id("ap_email")).sendKeys("aaa@gmail.com");
		driver.findElement(By.id("ap_password")).sendKeys("Aaa@01");
		//4. The user should click the continue button
		driver.findElement(By.id("continue")).click();
				
	}

}
